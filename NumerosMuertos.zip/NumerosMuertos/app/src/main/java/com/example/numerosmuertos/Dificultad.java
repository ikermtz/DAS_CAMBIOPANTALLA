package com.example.numerosmuertos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class Dificultad extends DialogFragment {

    ListenerDialogo miListener;
    public interface ListenerDialogo {
        void recogerValor(int i);
    }
    @NonNull
    @Override
    public AlertDialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        super.onCreateDialog(savedInstanceState);
        miListener = (ListenerDialogo) getActivity();

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("SELECCIONA UN NIVEL");
        final CharSequence[] opciones = {"FACIL", "MEDIO", "DIFICIL"};
        builder.setSingleChoiceItems(opciones, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                miListener.recogerValor(i);
            }
        });

        return builder.create();
    }
}

