package com.example.numerosmuertos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Juego extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.juegolayout);
        Intent intent = getIntent();
        int i = intent.getIntExtra("dificultad",0);
        TextView result = findViewById(R.id.nivel);
        switch(i){
            case 0:
                result.setText("facil");
                break;
            case 1:
                result.setText("medio");
                break;
            case 2:
                result.setText("dificil");
                break;
            default:
                System.out.println("eres down y no sabes elegir");
                }
    }

}
