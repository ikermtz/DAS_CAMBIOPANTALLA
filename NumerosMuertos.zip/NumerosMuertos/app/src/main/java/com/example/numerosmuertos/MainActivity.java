package com.example.numerosmuertos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements Dificultad.ListenerDialogo {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void jugar(View view){
        Dificultad dif = new Dificultad();
        dif.show(getSupportFragmentManager(), "etiqueta");

    }

    @Override
    public void recogerValor(int i){
        Intent intent = new Intent(this, Juego.class);
        intent.putExtra("dificultad", (int)i);
        MainActivity.this.startActivity(intent);
    }
}